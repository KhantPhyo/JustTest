#!/bin/sh

if [ x"${DESKTOP_SESSION##*/}" = x"lightdm-xsession" ]; then 
   sleep 20s
   killall conky
   cd "$HOME/.conky/MX-CowonBlue"
   conky -c "$HOME/.conky/MX-CowonBlue/MX-Cowon_blue_roboto" &
   exit 0
fi
if [ x"${DESKTOP_SESSION##*/}" = x"gnome" ]; then 
   # No widgets enabled!
   exit 0
fi
